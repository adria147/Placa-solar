/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.empresa_placas.solares;

import java.io.Console;
import java.util.ArrayList;
import java.util.function.DoubleUnaryOperator;

import javax.swing.text.StyledEditorKit.BoldAction;

public class Aparell {
    private String descripcio;
    private Double potencia;
    private boolean interruptor;

    public String getdescripcio(){
        return descripcio;
    }
    public Double getpotencia(){
        return potencia;
    }
    public boolean aparellinterruptor(){
        return interruptor;
    }
    ArrayList <Aparell> Listaaparell =new ArrayList<>();
    public Aparell(String descripcio,Double potencia,boolean interruptor){
        this.descripcio = descripcio;
        this.potencia = potencia;
        this.interruptor = interruptor;
    }
    public void addaparell (String nif,Double potencia,boolean interruptor){
        Listaaparell.add(new Aparell (descripcio,potencia,interruptor));
        System.out.println("");
    };  
    public void onAparell (String nif,String aparell){
    
    };
    public void offAparell (String nif,String aparell){
    
    };
}
     
    

