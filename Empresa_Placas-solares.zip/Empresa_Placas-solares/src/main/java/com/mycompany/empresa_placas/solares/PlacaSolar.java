package com.mycompany.empresa_placas.solares;

import java.io.Console;
import java.util.ArrayList;
import java.util.function.DoubleUnaryOperator;

import javax.swing.text.StyledEditorKit.BoldAction;

public class PlacaSolar {
    private double superficie;
    private double preu;
    private double potencia;

    public double getsuperficie(){
        return superficie;
    }
    public double getpreu(){
        return preu;
    }
    public double getpotencia(){
        return potencia;
    }
    ArrayList <PlacaSolar> Listaplacasolar = new ArrayList<>();
    public PlacaSolar(double superficie,double preu,double potencia){
        this.superficie = superficie;
        this.preu = preu;
        this.potencia = potencia;
    }
    public void addplaca (double superficie,double preu,double potencia){
        Listaplacasolar.add(new PlacaSolar(superficie,preu,potencia));
    };       
}
