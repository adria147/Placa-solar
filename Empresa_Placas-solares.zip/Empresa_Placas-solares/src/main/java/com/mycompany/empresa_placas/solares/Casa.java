
package com.mycompany.empresa_placas.solares;

import java.util.ArrayList;

public class Casa { 
    private String nif;
    private String nom;
    private float superficie;
    private boolean interruptor;
    
    public String getnif(){
        return  nif;
    }
    public String getnom(){
        return nom;
    }
    public float getsuperficie(){
        return superficie;
    }
    public boolean getinterruptor(){
        return interruptor;
    }
    ArrayList <Casa> Listcasa = new ArrayList<>(); 
    
    
    public Casa(String nif,String nom,float superficie,boolean interruptor){
        this.nif= nif;
        this.nom= nom;
        this.superficie = superficie;
        this.interruptor = interruptor;
    
    }
    public void addCasa (){
        Listcasa.add(new Casa(nif,nom,superficie,interruptor));
        System.out.println("");
    }
    public void onCasa (String nif){
        int total = 0;
        for (Casa pos: Listcasa) {
            if (.getinterruptor()) {
                total++;
            }
        }
    };
    public void list (){
    };
    public void info(String nif){

    };

}
   



